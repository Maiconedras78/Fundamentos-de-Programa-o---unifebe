import java.util.Scanner; // Importei isso aqui, mas não usei ainda. Vou deixar por precaução.

public class Main {
    public static void main(String[] args) {

        // n1 vai ser o PRIMEIRO número que a gente soma.
        int n1 = 0;

        // n2 vai ser o SEGUNDO número que a gente soma.
        // A sequência tem que começar com 0 e 1, então n1=0 e n2=1.
        int n2 = 1;

        // n3 é onde a gente guarda a SOMA. É tipo um auxiliar.
        int n3 = 0;

        System.out.println("A sequencia é: ");

        // Loop 'for'
        for (int i = 0; i < 10; i++) {

            // Imprime o número atual. (Na primeira vez, imprime o 0).
            System.out.println(n1);

            // Cálculo principal: Soma os dois números atuais para achar o próximo.
            n3 = n1 + n2;

            // O que era o segundo número (n2) vira o primeiro número para o próximo ciclo (novo n1).
            n1 = n2;


            // Essa parte de "trocar" os valores

        }

    }
}